﻿using System.Web.UI;

namespace Ass_5_1_12_2020.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}