﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace Ass_5_1_12_2020
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        SqlCommand cmd;
        SqlConnection con;
        SqlDataReader dr;
        protected void Page_Load(object sender, EventArgs e)
        {
            con = new SqlConnection(@"Data Source=PG-PUN-0017\SQLEXPRESS;Initial Catalog=myfirstdb;Integrated Security=True");
        }

        

        protected void Button1_Click(object sender, EventArgs e)
        {
           

            cmd = new SqlCommand();
            cmd.CommandText = "insert into employeeEE values (@p1,@p2,@p3,@p4)";
            cmd.Connection = con;

            cmd.Parameters.AddWithValue("@p1", TextBox1.Text);
            cmd.Parameters.AddWithValue("@p2", TextBox3.Text);
            cmd.Parameters.AddWithValue("@p3", TextBox5.Text);
            cmd.Parameters.AddWithValue("@p4", TextBox4.Text);


            con.Open();
            var no_of_rows_affected = cmd.ExecuteNonQuery();
            Response.Write(no_of_rows_affected + " inserted ");
            con.Close();

        }

        protected void Button2_Click(object sender, EventArgs e)
        {

            cmd = new SqlCommand();
            cmd.CommandText = "select * from employeeEE";
            cmd.Connection = con;
            cmd.CommandType = System.Data.CommandType.Text;
            con.Open();
            dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                GridView1.DataSource = dr;
                GridView1.DataBind();
            }
            con.Close();

        }

      

        protected void Button3_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand();
            cmd.CommandText = "update employeeEE set salary=@p2 where empname=@p1";
            cmd.Connection = con;

            cmd.Parameters.AddWithValue("@p1", TextBox1.Text);
            cmd.Parameters.AddWithValue("@p2", TextBox3.Text);
            


            con.Open();
            var no_of_rows_affected = cmd.ExecuteNonQuery();
            con.Close();
            Response.Write(no_of_rows_affected + " updated ");

        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand();
            cmd.CommandText = "delete from employeeEE where empname=@p1";
            cmd.Connection = con;

            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@p1", TextBox1.Text);


            con.Open();
            int no_of_rows_affected = cmd.ExecuteNonQuery();
            con.Close();
            Response.Write(no_of_rows_affected + " deleted ");

        }

        protected void Button5_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand();
            
            cmd.CommandText = "SELECT * FROM employeeEE ORDER BY Salary";
            cmd.Connection = con;

         
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@p2", TextBox1.Text);


            con.Open();
            int no_of_rows_affected = cmd.ExecuteNonQuery();
            con.Close();
            Response.Write(no_of_rows_affected + " Sorted ");
        }
    }
}

