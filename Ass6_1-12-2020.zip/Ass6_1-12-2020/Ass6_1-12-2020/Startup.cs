﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(Ass6_1_12_2020.Startup))]
namespace Ass6_1_12_2020
{
    public partial class Startup {
        public void Configuration(IAppBuilder app) {
            ConfigureAuth(app);
        }
    }
}
