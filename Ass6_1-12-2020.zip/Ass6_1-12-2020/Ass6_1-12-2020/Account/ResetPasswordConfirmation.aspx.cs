﻿using System.Web.UI;

namespace Ass6_1_12_2020.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}